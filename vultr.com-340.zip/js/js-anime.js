<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
				<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>Vultr.com</title>
		<style type="text/css">body,html{height:100%;width:100%}body{background:linear-gradient(90deg,#021048,#1e38a3);color:#fff;font-family:Roboto,sans-serif;font-size:25px;font-weight:700;line-height:150%;margin:0;padding:0;text-align:center}.line-break{display:static}.box{display:inline-block;line-height:200%;width:660px}.error_frame{border-top:1px solid #fff;margin-top:23px;opacity:.15;padding-top:20px}.vultr_logo{padding-top:150px}.vultr_bird{height:auto;padding-top:100px;width:250px}.previous_url{color:#fff;text-decoration:none}@media (max-device-width:414px){footer{font-size:25px}.desktop-break{display:none}.mobile-break:after{content:"\A";white-space:pre}.mobile-header{font-size:70px}.mobile-text{font-size:50px}.previous_url{color:#fff;font-size:23px;text-decoration:none}.box{font-size:30px;line-height:300%;width:90%}.vultr_logo{padding-bottom:50px;padding-top:150px;width:80%}.vultr_bird{width:50%}}</style>
	<meta http-equiv="refresh" content="35">
</head>
	<body>
		<div class="box">
			<img src="data:image/svg+xml;base64,PHN2ZyBpZD0ibG9nb19fb24tZGFyayIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgMjE3LjUgNTIiPjxkZWZzPjxzdHlsZT4uY2xzLTF7ZmlsbDojZmZmO30uY2xzLTJ7ZmlsbDojMDA3YmZjO30uY2xzLTN7ZmlsbDojNTFiOWZmO308L3N0eWxlPjwvZGVmcz48dGl0bGU+bG9nb19fb24tZGFyazwvdGl0bGU+PGcgaWQ9InRleHQiPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTIxNy4zLDM3Ljc1bC01LjQ3LTkuNDNBOC41LDguNSwwLDAsMCwyMDguNSwxMmgtMTJhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNVYyOWg4Ljc0bDUuOTUsMTAuMjVBMS40OSwxLjQ5LDAsMCwwLDIxNSw0MGgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNUExLjQ4LDEuNDgsMCwwLDAsMjE3LjMsMzcuNzVaTTE5OSwxNmg5LjVhNC41LDQuNSwwLDAsMSwwLDlIMTk5WiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTE4Ni41LDEyaC0yMWExLjUsMS41LDAsMCwwLTEuNSwxLjV2MWExLjUsMS41LDAsMCwwLDEuNSwxLjVIMTc0VjM4LjVhMS41LDEuNSwwLDAsMCwxLjUsMS41aDFhMS41LDEuNSwwLDAsMCwxLjUtMS41VjE2aDguNWExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxODYuNSwxMloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xNjQuNSwzNkgxNTFWMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxNmExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxNjQuNSwzNloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xMzksMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41VjI5YTcuNSw3LjUsMCwwLDEtMTUsMFYxMy41YTEuNSwxLjUsMCwwLDAtMS41LTEuNWgtMWExLjUsMS41LDAsMCwwLTEuNSwxLjVWMjlhMTEuNSwxMS41LDAsMCwwLDIzLDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMTA4LjUsMTJoLTFhMS41LDEuNSwwLDAsMC0xLjM5Ljk0TDk3LjUsMzQuNTksODguODQsMTIuOTRBMS41LDEuNSwwLDAsMCw4Ny40NSwxMmgtMUExLjUsMS41LDAsMCwwLDg1LDEzLjVhMS41NSwxLjU1LDAsMCwwLC4xMS41NmwxMCwyNUExLjQ5LDEuNDksMCwwLDAsOTYuNSw0MGgyYTEuNDksMS40OSwwLDAsMCwxLjM5LS45NGwxMC0yNWExLjU1LDEuNTUsMCwwLDAsLjExLS41NkExLjUsMS41LDAsMCwwLDEwOC41LDEyWiIvPjwvZz48ZyBpZD0ic3lnbmV0Ij48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0yMC45LDEuNEEzLDMsMCwwLDAsMTguMzcsMEgzQTMsMywwLDAsMCwuNDYsNC42bDMuMTUsNUwyNC4wNiw2LjRaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNMjQuMDYsNi40QTMsMywwLDAsMCwyMS41Miw1SDYuMTVBMywzLDAsMCwwLDMuNjEsOS42TDgsMTYuNmwyMC40NC0zLjJaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNOCwxNi42QTIuOTEsMi45MSwwLDAsMSw3LjU3LDE1YTMsMywwLDAsMSwzLTNIMjUuOTNhMywzLDAsMCwxLDIuNTQsMS40TDQyLjIyLDM1LjIxYTMsMywwLDAsMSwwLDMuMkwzNC41NCw1MC42YTMsMywwLDAsMS01LjA4LDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNDYuNzgsMjMuMTNhMywzLDAsMCwwLDUuMDcsMGwyLjY1LTQuMTksNS04YTMsMywwLDAsMCwwLTMuMjFsLTQtNi4zNEEzLDMsMCwwLDAsNTMsMEgzNy42M2EzLDMsMCwwLDAtMi41NCw0LjZaIi8+PC9nPjwvc3ZnPg==" alt="" style="padding-top:200px;"/>
			<div class="error_frame"></div>
			<div class="cf-browser-verification cf-im-under-attack">
    <noscript>
        <h1 style="color:#bd2426;">Please turn JavaScript on and reload the page.</h1>
    </noscript>
    <div id="cf-content">
        <div id="cf-bubbles">
            <div class="bubbles"></div>
            <div class="bubbles"></div>
            <div class="bubbles"></div>
        </div>
        <h1>Checking your browser before accessing www.vultr.com.</h1>
        <div id="no-cookie-warning" class="cookie-warning" style="display:none">
            <p style="color:#bd2426;">Please enable Cookies and reload the page</p>
        </div>
        <p>This process is automatic. Your browser will redirect to your requested content shortly.</p>
        <p id="cf-spinner-allow-5-secs">Please allow up to 5 seconds...</p>
        <p id="cf-spinner-redirecting" style="display:none">Redirecting...</p>
    </div>
    <form id="challenge-form" class="challenge-form" action="/dist/js/anime.js?v=1666878316&amp;__cf_chl_f_tk=1gXTy.3QiDGD.hUNLwPMY9rH6SRpu364TfsmMsKr3rU-1677715630-0-gaNycGzNB2U" method="POST" enctype="application/x-www-form-urlencoded">
        <input type="hidden" name="md" value="ET72glodR1Ash9_J.AsitlbSLyHRurPJDi0dnOMg8IY-1677715630-0-AaEyiiuK6oWpdPpBXT0yiLmUA3q4zRbtWb_mn_EUfHbKthtNDgTN8XeaLaBmrQ8-qG530zd8eTkdowq-pSdralF93Q4Dk13M452yK8qiPpf7P9RbqWv5Fagc-bh4lpr8il0g5Lb_mEu7Xl81K82KlthzSojGvnoYytpeLsDThq93ISh9g3NxEherfVvvIsivOh9l-AAi9Ql8jLWgxAg1c7Ts0N7jLuRndJckpJsjXpZpPKacGwB0jGyACUHtUBoHUp32E8P08zmNRsr2Vt2HDIVzW8elH3XC6NEPlz1bwCPik0eP3peNYFqdtBsgfTCuNr_fhBGy2-ckJ0wudtji-PuJl40zHmfO8DxfJGdt4qUNa2b8xbolhg3RiQLVyHToxy97v5EY8uyaPj8ERxnxu_Zldz8ai1hB6vF5CBoSC-IArVyIQIvYPLow6hkEO--zENyWIDYYnJ3Eis0LFkKNq_QSnsoX2bh1o8ip_qmzTVhYET9PCiS8OOgyDjGg5K4DsELaS-U2PWYv9VVB0jM9-vHHEJ1ziN3093lhCe9Ioi2SRB3Sw7rOsUQJ2SyV8ylfypFLrTDreBvPYc7qLsv_mhokQrbTC4-2zxLg6q559ac-z_yLul9LYSj4rTxXhiy0FdWKSBHID4dyJ8ojl1XsKcVDuyD02K1Xu-hhGAqUajQ_ASu5hjaRMWs3mhSg7v7g3Yp4mYiO_ViiFdvqvcI6BKe1baI-od26YxHXzv3Zo9q1rWzLnd3eedlbavOj7ou7Tko6CTVXluRt4j5QU4kO8SnTBYEMbZ4FrsXobQr-Mg0ZnGjw_kUC-ssMLtG38BVIdD7J-TmXVjdD21vGslDLr5hzRJ9rOlBHJfuaAUNKlE4fE8Cl3GybgnWV6cKQoGWRWVoM2zn2N0AP9Z_DfIsInPH1NSJEFRODUoDnXOJUH8z3ToICZQ_VxHkavwxbC2EyzND14XBv0UYFTMtRtRfyvhTGVhki_kFb4ZhHFg_rdSSUaH7yIa6Ej4fPuKS6VCDhBSfEf3brgAZhXRuebdWMMzmmYseWXgwlWyEtuRu10Pk1UingKlyQDMjlBv6SaHp3E5AyAojvnxodTzE5ta7ftjZJdmlc78Z0AD24d6nZmOA7_hIzfpx3bugiPtM7CuaUTNNPqgfOKlHe5uvn-SJZ6TeaU7HlQWT4Z0lMN-j6Mk-7HsaClM5s5D9x0JMQ_qvtuVh_Ewub2JC8Z2nEpaDyMZTkhiRSWdRvdCXb-Fxzie9XLtIfDxvueulDoVoDc8YqnsZFSysqBBFYnuVBS-FaSEiw90BGb6ik9okfKyXx35R7Hfruayj3VmhCH-bN1IMLQCXjnHtRG4WK4toHit_TnoILscpcswpLfhTWSazEdPu519vDL5FIK6AtiaXTUn_almv_THVWayeLQNdOFaAXaRFnNh5tZXLdfql5YZnGb71R8KfnXARnyQCo5UAo2SVOjzXWm-un9zfsm2s0g19Lt_61VGFflytnw3jpzJwFUXqr_bHhU_etHHblpe4XY5Ej7V7VB4TB_KQiQKYKsLGrc6mOYMQD-IFXGo1YgkRpe1J4yRFqc2DK_MO-0UDj7MXjOWdQnhgaJ6KpncfCdTiKVGIrhe51BpL-NxKtVutGJergqV68cbjgV0Ii1Ux4hdWnTaT09RXA2Sl2TYptTmjYCZCf5U5lGMWx97hWCS3oucRbsRSCo-gW7JcLoKrSesW8uBkzmMp_KLM4YPA8_54q-SapPuN9_VcziFVig8L6_-H9ItQ1mXZH2Zs6WYVFlheaG_1YL65Hb305XhrjpfLqoPZkKqg4s1_nShaIlyjRVu8z" />
    </form>
    <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7a1565e55f86c5a4')"></div>
    <script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.vultr.com',
            cType: 'non-interactive',
            cNounce: '91511',
            cRay: '7a1565e55f86c5a4',
            cHash: '01beb168872d298',
            cUPMDTk: "\/dist\/js\/anime.js?v=1666878316&__cf_chl_tk=1gXTy.3QiDGD.hUNLwPMY9rH6SRpu364TfsmMsKr3rU-1677715630-0-gaNycGzNB2U",
            cFPWv: 'g',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 1,
            cTplB: 'cf',
            cRq: {
                ru: 'aHR0cHM6Ly93d3cudnVsdHIuY29tL2Rpc3QvanMvYW5pbWUuanM/dj0xNjY2ODc4MzE2',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'ppqub27bAW9Y3tR59ALPfIko+cubrsCeHkqve5/3n+qph+MwX/S51nJjoj4Gqjs567u3y4C8Z1TMMU3hSW1TcuFtOyZjPR4ds5ajqcPC+LXXacwiaoyDIPyr0Cmpuay8/HgZcD3FV//4h31dIolugBLmU83JZFlrQ9Z7qFR4fZQCAWZKQdhlnTUUDnf+7fkDUCPLaOzjWTwhxjdSkXMmsBp4MoAf4Cfx0rmiq1kPyt26CIuaLbFzJ2FalcAoSfIpwhI1QeGQsJ9qmuLRjDWj3GYt6IbvjX+IshMFGXRsPIGfwAg1dM28U7/iJgLq++VBR2kKubefjFe3B+y+c+INr7qgj5miqEXx9WhsvczepGKTNgJfUQFpkZ/8TBCuRpgHgj/jrFHbwZV+VOk0mniVm99KYngGARd64DEf6mNr1nLXWnxEoJclWONR1eyCIBP8kr6NAl9QIiogesSXXNlev1B+uowO4+I9IAe7AlhQJxHNFD7JMLeMRsHrVdlvmXCZpq4LrapEghOaZwFzY1LfQ7TwG01rgTYIriO75n+o55FR7RF/zjzYqlJ7nYECsh2yzcBJHypIVEka5HNOeTG+2cjdx2P+5O9Q9M145+rf7HuZchkObcstDjGaHvHWn2BLGN4hylBOdYk2+ShENVoLY0QTxQTnwWtMJM0hmoFgpmhq34KYKzXiJ8iqLjaIJX9fOVm05ccFLH0vy4ZyGgMZNw==',
                t: 'MTY3NzcxNTYzMC45MzYwMDA=',
                m: 'PW4AWHmIdjw1sAvxZ1Mtfx+afeBcKm0C4ZGv+nWKDfk=',
                i1: 'pvXP3TZO2YP5dPRDxbQoFA==',
                i2: 'ZQ0jrfQLjWcZhyfINtebHQ==',
                zh: 'iQUouBNODGunr/NCuWfbRWWi0vP5Aj9NLkfKOZFVYyQ=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: '5G1zbnNPGlGRafw4p4kPAVAJ2/sq1g7EvlHwL4GBL7Q=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7a1565e55f86c5a4');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/g/orchestrate/jsch/v1?ray=7a1565e55f86c5a4';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/dist\/js\/anime.js?v=1666878316&__cf_chl_rt_tk=1gXTy.3QiDGD.hUNLwPMY9rH6SRpu364TfsmMsKr3rU-1677715630-0-gaNycGzNB2U" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>

</div>

		</div>
		<footer>
			<span id="previous_url"></span>
		</footer>
		<script type="text/javascript">function httpGetAsync(e,t){var n=new XMLHttpRequest;n.onreadystatechange=function(){4==n.readyState&&200==n.status&&t(n.responseText)},n.open("GET",e,!0),n.send(null)}function getIP(e){var t=/ip=(.*)$/m.exec(e);t&&(document.getElementById("your_ip").innerHTML="Your IP: "+t[1]),console.log(t)}httpGetAsync("/cdn-cgi/trace",getIP);</script>
	</body>
</html>