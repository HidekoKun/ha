<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
				<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>Vultr.com</title>
		<style type="text/css">body,html{height:100%;width:100%}body{background:linear-gradient(90deg,#021048,#1e38a3);color:#fff;font-family:Roboto,sans-serif;font-size:25px;font-weight:700;line-height:150%;margin:0;padding:0;text-align:center}.line-break{display:static}.box{display:inline-block;line-height:200%;width:660px}.error_frame{border-top:1px solid #fff;margin-top:23px;opacity:.15;padding-top:20px}.vultr_logo{padding-top:150px}.vultr_bird{height:auto;padding-top:100px;width:250px}.previous_url{color:#fff;text-decoration:none}@media (max-device-width:414px){footer{font-size:25px}.desktop-break{display:none}.mobile-break:after{content:"\A";white-space:pre}.mobile-header{font-size:70px}.mobile-text{font-size:50px}.previous_url{color:#fff;font-size:23px;text-decoration:none}.box{font-size:30px;line-height:300%;width:90%}.vultr_logo{padding-bottom:50px;padding-top:150px;width:80%}.vultr_bird{width:50%}}</style>
	<meta http-equiv="refresh" content="35">
</head>
	<body>
		<div class="box">
			<img src="data:image/svg+xml;base64,PHN2ZyBpZD0ibG9nb19fb24tZGFyayIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgMjE3LjUgNTIiPjxkZWZzPjxzdHlsZT4uY2xzLTF7ZmlsbDojZmZmO30uY2xzLTJ7ZmlsbDojMDA3YmZjO30uY2xzLTN7ZmlsbDojNTFiOWZmO308L3N0eWxlPjwvZGVmcz48dGl0bGU+bG9nb19fb24tZGFyazwvdGl0bGU+PGcgaWQ9InRleHQiPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTIxNy4zLDM3Ljc1bC01LjQ3LTkuNDNBOC41LDguNSwwLDAsMCwyMDguNSwxMmgtMTJhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNVYyOWg4Ljc0bDUuOTUsMTAuMjVBMS40OSwxLjQ5LDAsMCwwLDIxNSw0MGgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNUExLjQ4LDEuNDgsMCwwLDAsMjE3LjMsMzcuNzVaTTE5OSwxNmg5LjVhNC41LDQuNSwwLDAsMSwwLDlIMTk5WiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTE4Ni41LDEyaC0yMWExLjUsMS41LDAsMCwwLTEuNSwxLjV2MWExLjUsMS41LDAsMCwwLDEuNSwxLjVIMTc0VjM4LjVhMS41LDEuNSwwLDAsMCwxLjUsMS41aDFhMS41LDEuNSwwLDAsMCwxLjUtMS41VjE2aDguNWExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxODYuNSwxMloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xNjQuNSwzNkgxNTFWMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxNmExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxNjQuNSwzNloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xMzksMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41VjI5YTcuNSw3LjUsMCwwLDEtMTUsMFYxMy41YTEuNSwxLjUsMCwwLDAtMS41LTEuNWgtMWExLjUsMS41LDAsMCwwLTEuNSwxLjVWMjlhMTEuNSwxMS41LDAsMCwwLDIzLDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMTA4LjUsMTJoLTFhMS41LDEuNSwwLDAsMC0xLjM5Ljk0TDk3LjUsMzQuNTksODguODQsMTIuOTRBMS41LDEuNSwwLDAsMCw4Ny40NSwxMmgtMUExLjUsMS41LDAsMCwwLDg1LDEzLjVhMS41NSwxLjU1LDAsMCwwLC4xMS41NmwxMCwyNUExLjQ5LDEuNDksMCwwLDAsOTYuNSw0MGgyYTEuNDksMS40OSwwLDAsMCwxLjM5LS45NGwxMC0yNWExLjU1LDEuNTUsMCwwLDAsLjExLS41NkExLjUsMS41LDAsMCwwLDEwOC41LDEyWiIvPjwvZz48ZyBpZD0ic3lnbmV0Ij48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0yMC45LDEuNEEzLDMsMCwwLDAsMTguMzcsMEgzQTMsMywwLDAsMCwuNDYsNC42bDMuMTUsNUwyNC4wNiw2LjRaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNMjQuMDYsNi40QTMsMywwLDAsMCwyMS41Miw1SDYuMTVBMywzLDAsMCwwLDMuNjEsOS42TDgsMTYuNmwyMC40NC0zLjJaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNOCwxNi42QTIuOTEsMi45MSwwLDAsMSw3LjU3LDE1YTMsMywwLDAsMSwzLTNIMjUuOTNhMywzLDAsMCwxLDIuNTQsMS40TDQyLjIyLDM1LjIxYTMsMywwLDAsMSwwLDMuMkwzNC41NCw1MC42YTMsMywwLDAsMS01LjA4LDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNDYuNzgsMjMuMTNhMywzLDAsMCwwLDUuMDcsMGwyLjY1LTQuMTksNS04YTMsMywwLDAsMCwwLTMuMjFsLTQtNi4zNEEzLDMsMCwwLDAsNTMsMEgzNy42M2EzLDMsMCwwLDAtMi41NCw0LjZaIi8+PC9nPjwvc3ZnPg==" alt="" style="padding-top:200px;"/>
			<div class="error_frame"></div>
			<div class="cf-browser-verification cf-im-under-attack">
    <noscript>
        <h1 style="color:#bd2426;">Please turn JavaScript on and reload the page.</h1>
    </noscript>
    <div id="cf-content">
        <div id="cf-bubbles">
            <div class="bubbles"></div>
            <div class="bubbles"></div>
            <div class="bubbles"></div>
        </div>
        <h1>Checking your browser before accessing www.vultr.com.</h1>
        <div id="no-cookie-warning" class="cookie-warning" style="display:none">
            <p style="color:#bd2426;">Please enable Cookies and reload the page</p>
        </div>
        <p>This process is automatic. Your browser will redirect to your requested content shortly.</p>
        <p id="cf-spinner-allow-5-secs">Please allow up to 5 seconds...</p>
        <p id="cf-spinner-redirecting" style="display:none">Redirecting...</p>
    </div>
    <form id="challenge-form" class="challenge-form" action="/dist/js/vendor.js?v=1666878316&amp;__cf_chl_f_tk=qX1GfaHA1h.Pv5nyjZmFxlfpTfAZV6gUpeLjSInZWXg-1677715629-0-gaNycGzNB2U" method="POST" enctype="application/x-www-form-urlencoded">
        <input type="hidden" name="md" value="ZC.y8QjFFLUz8oUwViYCAE9eh.NsAD5guKOjo0NNFvM-1677715629-0-AZfgYAZlbzGBGS-YfR5h41xiyb9bFvpnO7EHgU-jExqXybTHixbluzQ1Ks6FgAP5XqsKwGInr_3g0MDn9nIasyj_1CG-kmZgH1i4glwG4mhVyooxEuqdGoMXgBTNrl9C2U4tAC-2NTt2oKIXYZig4-EQ8_WnCQ1vwfL3Agi6KuvLUdr_lJb6VW2WEU1PJYAjbRGn6XZkIk7ddEuSEvAW9U0X2IE6ovMmRfQ-mB8b2qgg3fQ5t66SHY18jt7pKG23ciSd0nILin5VH2p8pbMHGV7tfGA0oEomWi8592ujzzyEU3X1sEig2JlxPwvXqBdVKVdZy0xK_yH41Yvh6IlXTnYFw-AoWWNRSobY8gLk9YJEgNni-XUBZ5tNcCG2O-XSnyX246Y5VDmRzeQWFCJg5r4CbxmfbDUWRoRylfS4jMUtTJn8CU-beZXEEEVCWy9BtwTg7soNENFRx0QkGYIVkKarhv_3Q-AuT3KGWAYQ0TZ-BCwztoNIY2OW2axLmqTe-Bw3mL29_dXN99yU5vqKjk82V2M5IbDmBQyN22UjrNJ0bO51cgi2liDrgmtzgQHqQFZjFDMR-OBJ1DuyJnTGelUDXn3_Ju6EtdS2oCqvl62ALps19seYA2OCTc7ZSosHxREhqPBh1C0-K3eD4RAM4K7h6nVvxhCew9cthC5ZD19ySlUR6J51m7t7cbNlyd3MvX3SjjTg-vixfdCpWNzU1rbNpwX7ZKSgrLitJLHXvCFIJ0jMJ_M8__al_zaHRGyBU4wKL817znZByMcX65Kd-RanQQXEKAvN3EYVDtPoVWUYI24OfPcpbSqjowqPbXp1IK3wLEeii8s954kl3x1dXzZBN6z6q9H0dNsuxvdd5cR2D2VmLOe5sCX_bg4bMjq95vtOfVaTN4cmuHS4HsXPubkDtU7Jr95BovaoeSwiHCXQ_PaDEZ7RFFDxAq4RR77RIQY2v04wr86bt-SgcqJKuq_weouXcmppG31kzSwuWkdhfm77d0Pgr4hSOjczeiSOBkHRF1nz9QYMWFG-poKvc7xGQdpJLVtzslNbe5-oQw9cFicwPNFtYHHUIoA3zghJS0oB-zArTN_q0mvFsRAVrjq32JQGO1RmUqFeyieOPi_7jFg0gdpRE_ztWACz6J8DIQG32XsZnUfcmrBD9yA-zEfD2M-DMiQRUKOEikgUN2Jabo8TuQVnGBNIBiP50uUs6nUXj0L0Xx3HKMhDrp27ZNoIdP2MvYM2BhdwjSi5l95qkiBeqScOnob47_LlBpjfQIZ-PhYXLBELJ4ecx-gR25S-CiqunswmcGtDqE79rIIrHiBIHKcWtrMEkq6ZQ-AgCOM_l6SpqSyJt6PW5KeCxsMLOQjD8zeQpOeqg5V2lIv-scP52xckqYk9J6OMAtwi2wXz61AUnqZS8HafqE39MvLwykreXwsgJNvcpk31BprmMqGYhlYfPCKunHbRLeopWR-82QYeFxJHdxFzkm1y2i3yfV1z3ALYKISdzBnw8sTIIIaNBXVKns6AfT0POyWZayMNg2bNDD7tZNFhYS70nUUa7nREq3kr0gHCrVh5WQXlalXpxzBAh2qR6c-JW2mP-_K5IbeSseDFWFeFj6QIYXqe6SUtX2Ss3N3dCDaiX0cj9y00HsGBShyQZ0_zcAdjUKaAQVhLlmxDEClFDsOC9pJsszSHUH7JtnJz1rYaEPGiTBgfThp8d39cjmvrpDtVxb03enTYbJEXJ6ay7MmZ6wi7cBf8tduncpmpqIVpbpguN1gAV4If_MCwYJlmBhUa2bzhYpzuaGmY-wb_D8NBMqTB-yDlCCtYnb9jZHNxRC_v" />
    </form>
    <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7a1565dd0977c5b8')"></div>
    <script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.vultr.com',
            cType: 'non-interactive',
            cNounce: '60090',
            cRay: '7a1565dd0977c5b8',
            cHash: '82b084f0342f00d',
            cUPMDTk: "\/dist\/js\/vendor.js?v=1666878316&__cf_chl_tk=qX1GfaHA1h.Pv5nyjZmFxlfpTfAZV6gUpeLjSInZWXg-1677715629-0-gaNycGzNB2U",
            cFPWv: 'g',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 1,
            cTplB: 'cf',
            cRq: {
                ru: 'aHR0cHM6Ly93d3cudnVsdHIuY29tL2Rpc3QvanMvdmVuZG9yLmpzP3Y9MTY2Njg3ODMxNg==',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'tY/ZkrU29Wthq2AEOsqkamc4JCZySKvxijEivJww38Gc7NS2ZvTS4vnJmXfBIP5H2zXs0fgPtM+r2QyHUT33Z/96qUOlxoqAfBkUeCkauQY8ngHP0nhuS+yOtpHsgMfgLfw/vDU6vGZPwXJ8RWp/gHqKIKoyj0sLROnUGvdV3M9Te43/22IS0Hamyb75yzx7xpYs9TUb4tQSRTJupBSbn0n+mpkERsPzQnAtFXJiKMhEBuUSYHGQ3EfDglb/OVVvSw+JZye5kXER346qYNuNcJ7pv3Ijachlg+fY5M7U4CasxZkeqKrdqWSetOgrWAmM5lWVUA/l25pfNRkPP/kDpN6PYmovb7LKeKUMqLawG1baPw7NNRhGrGkk9q9B4ONgJ70WPtXPDbFFOGWvRop8/VVejr4fqfPM5fHQmyuDQBYFfmY2HR92jKty05fvyQdCzZNk0ccsKRMkPCehjY7Nrqfs7eOzQHbw3enPV5sf013ne2jCOJ8jiXdtfgy3BgiYkHpfy6r/XuhrmsNI1UZbIOWUwVxo4FiqADhbkkCdUsXTTI8e1VGIYZjWTUn4AfheVt3UWdFRztXre9NbXI34g/ZoPtEB9Vo4C/kc4B+v/6ebKvPMmbHxAj7oZ1w5pxqTx5s4NF0R2jIT4spANG3I9YMMuJLxNannzpiKkyjQCa5rCCQhMEgKVW5h7Vic2mw+D+D2tuhNRg2+GilwKAq59Q==',
                t: 'MTY3NzcxNTYyOS42MDYwMDA=',
                m: 'nS+XMUj4SdHCv3FAs+s8XWiXedTw9M0M2TABrcmLMbU=',
                i1: 'KgQTsvnjSfuo5+uC+opgZw==',
                i2: 'NnMCWvLVVHSEbTmV6LM4ZQ==',
                zh: 'iQUouBNODGunr/NCuWfbRWWi0vP5Aj9NLkfKOZFVYyQ=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: '5G1zbnNPGlGRafw4p4kPAVAJ2/sq1g7EvlHwL4GBL7Q=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7a1565dd0977c5b8');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/g/orchestrate/jsch/v1?ray=7a1565dd0977c5b8';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/dist\/js\/vendor.js?v=1666878316&__cf_chl_rt_tk=qX1GfaHA1h.Pv5nyjZmFxlfpTfAZV6gUpeLjSInZWXg-1677715629-0-gaNycGzNB2U" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>

</div>

		</div>
		<footer>
			<span id="previous_url"></span>
		</footer>
		<script type="text/javascript">function httpGetAsync(e,t){var n=new XMLHttpRequest;n.onreadystatechange=function(){4==n.readyState&&200==n.status&&t(n.responseText)},n.open("GET",e,!0),n.send(null)}function getIP(e){var t=/ip=(.*)$/m.exec(e);t&&(document.getElementById("your_ip").innerHTML="Your IP: "+t[1]),console.log(t)}httpGetAsync("/cdn-cgi/trace",getIP);</script>
	</body>
</html>