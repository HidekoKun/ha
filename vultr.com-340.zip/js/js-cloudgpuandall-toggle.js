<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
				<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>Vultr.com</title>
		<style type="text/css">body,html{height:100%;width:100%}body{background:linear-gradient(90deg,#021048,#1e38a3);color:#fff;font-family:Roboto,sans-serif;font-size:25px;font-weight:700;line-height:150%;margin:0;padding:0;text-align:center}.line-break{display:static}.box{display:inline-block;line-height:200%;width:660px}.error_frame{border-top:1px solid #fff;margin-top:23px;opacity:.15;padding-top:20px}.vultr_logo{padding-top:150px}.vultr_bird{height:auto;padding-top:100px;width:250px}.previous_url{color:#fff;text-decoration:none}@media (max-device-width:414px){footer{font-size:25px}.desktop-break{display:none}.mobile-break:after{content:"\A";white-space:pre}.mobile-header{font-size:70px}.mobile-text{font-size:50px}.previous_url{color:#fff;font-size:23px;text-decoration:none}.box{font-size:30px;line-height:300%;width:90%}.vultr_logo{padding-bottom:50px;padding-top:150px;width:80%}.vultr_bird{width:50%}}</style>
	<meta http-equiv="refresh" content="35">
</head>
	<body>
		<div class="box">
			<img src="data:image/svg+xml;base64,PHN2ZyBpZD0ibG9nb19fb24tZGFyayIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgMjE3LjUgNTIiPjxkZWZzPjxzdHlsZT4uY2xzLTF7ZmlsbDojZmZmO30uY2xzLTJ7ZmlsbDojMDA3YmZjO30uY2xzLTN7ZmlsbDojNTFiOWZmO308L3N0eWxlPjwvZGVmcz48dGl0bGU+bG9nb19fb24tZGFyazwvdGl0bGU+PGcgaWQ9InRleHQiPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTIxNy4zLDM3Ljc1bC01LjQ3LTkuNDNBOC41LDguNSwwLDAsMCwyMDguNSwxMmgtMTJhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNVYyOWg4Ljc0bDUuOTUsMTAuMjVBMS40OSwxLjQ5LDAsMCwwLDIxNSw0MGgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNUExLjQ4LDEuNDgsMCwwLDAsMjE3LjMsMzcuNzVaTTE5OSwxNmg5LjVhNC41LDQuNSwwLDAsMSwwLDlIMTk5WiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTE4Ni41LDEyaC0yMWExLjUsMS41LDAsMCwwLTEuNSwxLjV2MWExLjUsMS41LDAsMCwwLDEuNSwxLjVIMTc0VjM4LjVhMS41LDEuNSwwLDAsMCwxLjUsMS41aDFhMS41LDEuNSwwLDAsMCwxLjUtMS41VjE2aDguNWExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxODYuNSwxMloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xNjQuNSwzNkgxNTFWMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxNmExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxNjQuNSwzNloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xMzksMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41VjI5YTcuNSw3LjUsMCwwLDEtMTUsMFYxMy41YTEuNSwxLjUsMCwwLDAtMS41LTEuNWgtMWExLjUsMS41LDAsMCwwLTEuNSwxLjVWMjlhMTEuNSwxMS41LDAsMCwwLDIzLDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMTA4LjUsMTJoLTFhMS41LDEuNSwwLDAsMC0xLjM5Ljk0TDk3LjUsMzQuNTksODguODQsMTIuOTRBMS41LDEuNSwwLDAsMCw4Ny40NSwxMmgtMUExLjUsMS41LDAsMCwwLDg1LDEzLjVhMS41NSwxLjU1LDAsMCwwLC4xMS41NmwxMCwyNUExLjQ5LDEuNDksMCwwLDAsOTYuNSw0MGgyYTEuNDksMS40OSwwLDAsMCwxLjM5LS45NGwxMC0yNWExLjU1LDEuNTUsMCwwLDAsLjExLS41NkExLjUsMS41LDAsMCwwLDEwOC41LDEyWiIvPjwvZz48ZyBpZD0ic3lnbmV0Ij48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0yMC45LDEuNEEzLDMsMCwwLDAsMTguMzcsMEgzQTMsMywwLDAsMCwuNDYsNC42bDMuMTUsNUwyNC4wNiw2LjRaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNMjQuMDYsNi40QTMsMywwLDAsMCwyMS41Miw1SDYuMTVBMywzLDAsMCwwLDMuNjEsOS42TDgsMTYuNmwyMC40NC0zLjJaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNOCwxNi42QTIuOTEsMi45MSwwLDAsMSw3LjU3LDE1YTMsMywwLDAsMSwzLTNIMjUuOTNhMywzLDAsMCwxLDIuNTQsMS40TDQyLjIyLDM1LjIxYTMsMywwLDAsMSwwLDMuMkwzNC41NCw1MC42YTMsMywwLDAsMS01LjA4LDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNDYuNzgsMjMuMTNhMywzLDAsMCwwLDUuMDcsMGwyLjY1LTQuMTksNS04YTMsMywwLDAsMCwwLTMuMjFsLTQtNi4zNEEzLDMsMCwwLDAsNTMsMEgzNy42M2EzLDMsMCwwLDAtMi41NCw0LjZaIi8+PC9nPjwvc3ZnPg==" alt="" style="padding-top:200px;"/>
			<div class="error_frame"></div>
			<div class="cf-browser-verification cf-im-under-attack">
    <noscript>
        <h1 style="color:#bd2426;">Please turn JavaScript on and reload the page.</h1>
    </noscript>
    <div id="cf-content">
        <div id="cf-bubbles">
            <div class="bubbles"></div>
            <div class="bubbles"></div>
            <div class="bubbles"></div>
        </div>
        <h1>Checking your browser before accessing www.vultr.com.</h1>
        <div id="no-cookie-warning" class="cookie-warning" style="display:none">
            <p style="color:#bd2426;">Please enable Cookies and reload the page</p>
        </div>
        <p>This process is automatic. Your browser will redirect to your requested content shortly.</p>
        <p id="cf-spinner-allow-5-secs">Please allow up to 5 seconds...</p>
        <p id="cf-spinner-redirecting" style="display:none">Redirecting...</p>
    </div>
    <form id="challenge-form" class="challenge-form" action="/dist/js/cloudgpuandall-toggle.js?v=1675445537&amp;__cf_chl_f_tk=bxKtsOgXCeRATXLPlO4VXAVehAmVzVZvkTqk98MVh4I-1677715632-0-gaNycGzNB6U" method="POST" enctype="application/x-www-form-urlencoded">
        <input type="hidden" name="md" value="TQmWJf4_X.JoIaJbmBrBksyfXDTcx0JvNOMzYglCYzU-1677715632-0-AeAoUsjLfJ4DMQNiiT2SMekLgN6fnDagV8AqnMY8S22UohZ_eyBEwvniG0MFCWkm1yhmRNaVbDQmlNSH02JwfNdD6DfeGmsEKA5ElF2qKNuhsqRgdHfs-OJ5-bxFTyBtz5j2zG5T-yThgyffoiG9vhFRGiceoRPN0RQVg0joQb2M_dyymYCMRxS0NtfBuNbTUqxsPwoGbAXegx9V9kdPGF87jYPOX7HBi6axKzRSZ-l3v2x5aPaSBGI8GT74251ZKpo8cZwLJaazIoj6Gjt1Z1n4dauP-kgFw5N44XMRxws7gu1Twd3ywF1kcz1q3H_9zzV3JhmvnIzixhd23MgbZKR_PvHFzU0cAvcvuIrbluQit0bMHhOKbl889W-5g1Tzn2Z43pHVAEsktUWEO8oAiNABarjYOKAzYZNKgPa7qK04XqvKTxOwH2IqXqWmbdeRrZav4ZpeNTCgnMYL29vvsn6rpOpcLXshdo4WDAJJ5ccd65q__2ew6WcRkRWhUwyQ98jYTN92ic_Wypry_o09Mze_3beE5vJxLse8LovIuDdOJn9J9XgVuxTEZEJp69eD1z-hkLH_KUbNyUPNN-ennilKg4lGgiKBGqf7vrhyMiZoaB0CBgCMaUwP0kUO2wFsM8mygaPrVkUr7L4VQ6zCxHLr0yR40Jr8tpUAHuH3ysNgJ0EO3PaK0kUZwlxZazXwxEXL1NslQwQCDd-pQh-Ffb5nzrMHGMq6HdHqLBTQIOMAGkc_fTqN9ELW9pFzwuh12CmXOjDTO4cptbVmJOhaqzBgQcbGZ9TVPXJgvyRgs65x85N5tH60_TxTCvoj0eGCi_qKov3jO8Zs_imNGRnya0h96RI3HV1uI0iyXQ4ZLKPHZK2pXyskYVPi-eGLqet_VGZijq-CQ4vzQ_TPecDNdCB0VrHEQ0q0mQaXJBj5h13gSjh0IODQG1T2MiDEQDpdIs_Y-ALdCXq1oIoWaWFLn-4A389_oFJmNSbr8D3fgpW5Vrg0KPSJSjJ5WWizAjtRDGZtZHxC95ePxauTKgmiiF5lPTtPj1uGGGtf10HgtFtHZum6lVtI4gCr2t50locACg_eB5x1wy8yF-O8RmF2neNIxFd3nj-XLlYZAYsI-0eMsjFjqo5fjvkfWY4LLatnbN1zSRtYVvSJIQHoBRnEdwFWUdKjJowyeX8OM12iDNDiNIrY8snDFBN-sm2CoVZp5-49T966Akcu962bTwn3rYT20KyGjM2KktwMM-l3Fb4bxboWRNW6UYimbGYIWOuaVhZRf-xtzYo28an5RlLfIcCu6tcyOxmbRLRx1F0UKOgJIYcANYyCVyiRc_tmGo75I-Fz0YW_gi0fry68cK3UEme2LQInhQ8raWNn_x01CNS-3IDTJxjRm5XTnOS0Ae8EAZqt4-gjBO3_EcOQ-5gmOKVOBMvxqBAk9ByyKbFu64MjhracqkIammnnc1VAszpY8FqSEXFoO-eoQb1sos8_xYOIf8MWY6gyshmocKcAaBWNQszpg-CVQH4bPQOgoRbKnFq_TkrImLX2w6o3TCDIXDYP_Bm0zQ2euXnTEgWWQ3cjuVHUUVnUHzU2xntKSqLh0cozdKpcM74tmAJaqlV6oiEAmYOAm86jibUyQMFsh6tmtzYvc1RCSNqhdMON6SGhPsZkTHBb4_GdeIopQ6_IkB0PxheEjAEEpkFeUR2v3L0CT8MzKfC6HHJRAlfLdprliMWl95aKGAc3ttR8pKHuE6OdGh11EyycqgtBq6t8rROTejSVCm5oGCu5127-OtHEy-UnIsBAZtqxbeNhRACvfUjv_oQpQ-Nua4rnTjWb1VMTchozZU-9jZpsxH51EMvSpBrtt6q2SQkQjCJDEowcC_NaEog9Q0zx0BIBaGpqXKF9" />
    </form>
    <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7a1565eedbf527ae')"></div>
    <script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.vultr.com',
            cType: 'non-interactive',
            cNounce: '43161',
            cRay: '7a1565eedbf527ae',
            cHash: '18d5c6d904de89c',
            cUPMDTk: "\/dist\/js\/cloudgpuandall-toggle.js?v=1675445537&__cf_chl_tk=bxKtsOgXCeRATXLPlO4VXAVehAmVzVZvkTqk98MVh4I-1677715632-0-gaNycGzNB6U",
            cFPWv: 'g',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 1,
            cTplB: 'cf',
            cRq: {
                ru: 'aHR0cHM6Ly93d3cudnVsdHIuY29tL2Rpc3QvanMvY2xvdWRncHVhbmRhbGwtdG9nZ2xlLmpzP3Y9MTY3NTQ0NTUzNw==',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: '6MvEzyfs0AQUGfwXr5bgI5OCISTA2wALRVQ0T1pYqmrFxf60TqssGzaF/liQ03n4+C7XDj57KzOZbB3g0f+WgiETrfGafSuV1fIV5MJoAH7NZUCqPjT3evqm2qnzzkSBt76fXhyJN/mGfrrXlDa2XGfXMQhlPzmY4Xa0yy7zFO83bnhDLpGKKeNW48H03x4EFOPwjKCqKblEfO/Rly/vEK2RXMU0hZszbvlnZhssKv6ot+bdbLddPrQsqKGcjmoaGG204fZ0F/aoVlritgxfE2CCih25YKPDc3vuAN0wuosnnPapGqEj9yfzhw8/fvqqJYRV1Xz5pFxcO+Ci8qYvr4/ebSp1hpTSBnOrMpMJqJqEj+cIXLfzfKmAqa9cUwfRrz8BmNOz+VzouZv/jGrqn/aPIT1sW0BoSZ2YVLwz2oq043VvmohKpKXQB5eHdabWA6N8U16JAEjBTTQDzyjMX8YyQpSl/trJhvzqddr/WWjOhppuGMTFb92NJCEXUZO7FF46VIjX9gUN2bEOaCka5H3U1o5qrxVI+zeQtPSKUMect97NKfmTPTaDKqZi8ZJAfRXRXu1uXD98YRauk8/WJjk2YmDCqvg24EUB/7SWA4r0LX08iIGN5Mxw7Gg38wRT3lgZbpc2vr5FWCR4wrYo0YDz11LWsp/SssREwxQiTI91l3Us1XlPjfpKp/X9hXuEGavr6iXg30YAhjBsu3FVyg==',
                t: 'MTY3NzcxNTYzMi40NjEwMDA=',
                m: 'r+zd5muJUVtXFROHgy5CEg6+0bL0IVZug9/bslJL1mg=',
                i1: 'K5nrnnoMAzwfqPOxiavG6Q==',
                i2: 'V8yI/jJS7CXEmB2Glv4ifA==',
                zh: 'iQUouBNODGunr/NCuWfbRWWi0vP5Aj9NLkfKOZFVYyQ=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: '5G1zbnNPGlGRafw4p4kPAVAJ2/sq1g7EvlHwL4GBL7Q=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7a1565eedbf527ae');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/g/orchestrate/jsch/v1?ray=7a1565eedbf527ae';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/dist\/js\/cloudgpuandall-toggle.js?v=1675445537&__cf_chl_rt_tk=bxKtsOgXCeRATXLPlO4VXAVehAmVzVZvkTqk98MVh4I-1677715632-0-gaNycGzNB6U" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>

</div>

		</div>
		<footer>
			<span id="previous_url"></span>
		</footer>
		<script type="text/javascript">function httpGetAsync(e,t){var n=new XMLHttpRequest;n.onreadystatechange=function(){4==n.readyState&&200==n.status&&t(n.responseText)},n.open("GET",e,!0),n.send(null)}function getIP(e){var t=/ip=(.*)$/m.exec(e);t&&(document.getElementById("your_ip").innerHTML="Your IP: "+t[1]),console.log(t)}httpGetAsync("/cdn-cgi/trace",getIP);</script>
	</body>
</html>