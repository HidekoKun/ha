<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
				<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>Vultr.com</title>
		<style type="text/css">body,html{height:100%;width:100%}body{background:linear-gradient(90deg,#021048,#1e38a3);color:#fff;font-family:Roboto,sans-serif;font-size:25px;font-weight:700;line-height:150%;margin:0;padding:0;text-align:center}.line-break{display:static}.box{display:inline-block;line-height:200%;width:660px}.error_frame{border-top:1px solid #fff;margin-top:23px;opacity:.15;padding-top:20px}.vultr_logo{padding-top:150px}.vultr_bird{height:auto;padding-top:100px;width:250px}.previous_url{color:#fff;text-decoration:none}@media (max-device-width:414px){footer{font-size:25px}.desktop-break{display:none}.mobile-break:after{content:"\A";white-space:pre}.mobile-header{font-size:70px}.mobile-text{font-size:50px}.previous_url{color:#fff;font-size:23px;text-decoration:none}.box{font-size:30px;line-height:300%;width:90%}.vultr_logo{padding-bottom:50px;padding-top:150px;width:80%}.vultr_bird{width:50%}}</style>
	<meta http-equiv="refresh" content="35">
</head>
	<body>
		<div class="box">
			<img src="data:image/svg+xml;base64,PHN2ZyBpZD0ibG9nb19fb24tZGFyayIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgMjE3LjUgNTIiPjxkZWZzPjxzdHlsZT4uY2xzLTF7ZmlsbDojZmZmO30uY2xzLTJ7ZmlsbDojMDA3YmZjO30uY2xzLTN7ZmlsbDojNTFiOWZmO308L3N0eWxlPjwvZGVmcz48dGl0bGU+bG9nb19fb24tZGFyazwvdGl0bGU+PGcgaWQ9InRleHQiPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTIxNy4zLDM3Ljc1bC01LjQ3LTkuNDNBOC41LDguNSwwLDAsMCwyMDguNSwxMmgtMTJhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNVYyOWg4Ljc0bDUuOTUsMTAuMjVBMS40OSwxLjQ5LDAsMCwwLDIxNSw0MGgxYTEuNSwxLjUsMCwwLDAsMS41LTEuNUExLjQ4LDEuNDgsMCwwLDAsMjE3LjMsMzcuNzVaTTE5OSwxNmg5LjVhNC41LDQuNSwwLDAsMSwwLDlIMTk5WiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTE4Ni41LDEyaC0yMWExLjUsMS41LDAsMCwwLTEuNSwxLjV2MWExLjUsMS41LDAsMCwwLDEuNSwxLjVIMTc0VjM4LjVhMS41LDEuNSwwLDAsMCwxLjUsMS41aDFhMS41LDEuNSwwLDAsMCwxLjUtMS41VjE2aDguNWExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxODYuNSwxMloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xNjQuNSwzNkgxNTFWMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41djI1YTEuNSwxLjUsMCwwLDAsMS41LDEuNWgxNmExLjUsMS41LDAsMCwwLDEuNS0xLjV2LTFBMS41LDEuNSwwLDAsMCwxNjQuNSwzNloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xMzksMTMuNWExLjUsMS41LDAsMCwwLTEuNS0xLjVoLTFhMS41LDEuNSwwLDAsMC0xLjUsMS41VjI5YTcuNSw3LjUsMCwwLDEtMTUsMFYxMy41YTEuNSwxLjUsMCwwLDAtMS41LTEuNWgtMWExLjUsMS41LDAsMCwwLTEuNSwxLjVWMjlhMTEuNSwxMS41LDAsMCwwLDIzLDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMTA4LjUsMTJoLTFhMS41LDEuNSwwLDAsMC0xLjM5Ljk0TDk3LjUsMzQuNTksODguODQsMTIuOTRBMS41LDEuNSwwLDAsMCw4Ny40NSwxMmgtMUExLjUsMS41LDAsMCwwLDg1LDEzLjVhMS41NSwxLjU1LDAsMCwwLC4xMS41NmwxMCwyNUExLjQ5LDEuNDksMCwwLDAsOTYuNSw0MGgyYTEuNDksMS40OSwwLDAsMCwxLjM5LS45NGwxMC0yNWExLjU1LDEuNTUsMCwwLDAsLjExLS41NkExLjUsMS41LDAsMCwwLDEwOC41LDEyWiIvPjwvZz48ZyBpZD0ic3lnbmV0Ij48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0yMC45LDEuNEEzLDMsMCwwLDAsMTguMzcsMEgzQTMsMywwLDAsMCwuNDYsNC42bDMuMTUsNUwyNC4wNiw2LjRaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNMjQuMDYsNi40QTMsMywwLDAsMCwyMS41Miw1SDYuMTVBMywzLDAsMCwwLDMuNjEsOS42TDgsMTYuNmwyMC40NC0zLjJaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNOCwxNi42QTIuOTEsMi45MSwwLDAsMSw3LjU3LDE1YTMsMywwLDAsMSwzLTNIMjUuOTNhMywzLDAsMCwxLDIuNTQsMS40TDQyLjIyLDM1LjIxYTMsMywwLDAsMSwwLDMuMkwzNC41NCw1MC42YTMsMywwLDAsMS01LjA4LDBaIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNDYuNzgsMjMuMTNhMywzLDAsMCwwLDUuMDcsMGwyLjY1LTQuMTksNS04YTMsMywwLDAsMCwwLTMuMjFsLTQtNi4zNEEzLDMsMCwwLDAsNTMsMEgzNy42M2EzLDMsMCwwLDAtMi41NCw0LjZaIi8+PC9nPjwvc3ZnPg==" alt="" style="padding-top:200px;"/>
			<div class="error_frame"></div>
			<div class="cf-browser-verification cf-im-under-attack">
    <noscript>
        <h1 style="color:#bd2426;">Please turn JavaScript on and reload the page.</h1>
    </noscript>
    <div id="cf-content">
        <div id="cf-bubbles">
            <div class="bubbles"></div>
            <div class="bubbles"></div>
            <div class="bubbles"></div>
        </div>
        <h1>Checking your browser before accessing www.vultr.com.</h1>
        <div id="no-cookie-warning" class="cookie-warning" style="display:none">
            <p style="color:#bd2426;">Please enable Cookies and reload the page</p>
        </div>
        <p>This process is automatic. Your browser will redirect to your requested content shortly.</p>
        <p id="cf-spinner-allow-5-secs">Please allow up to 5 seconds...</p>
        <p id="cf-spinner-redirecting" style="display:none">Redirecting...</p>
    </div>
    <form id="challenge-form" class="challenge-form" action="/dist/js/main.js?v=1677691956&amp;__cf_chl_f_tk=uKGf1B2XdG7WbLSF8d6f_tuCdVYInTLOuyfQx9TT42s-1677715629-0-gaNycGzNB3s" method="POST" enctype="application/x-www-form-urlencoded">
        <input type="hidden" name="md" value="nzqVEIOzNyzQQYpscJ.B6IR6Gf2rUqmkHC.mc87Mll4-1677715629-0-AaympNYz5-wEWCf4Divl1iA7BNCLYnosCv_xALOKvJ5SFh3WLCaCDv3QPd1YyeraYEuEGVnSyPxDvv_IO6-JcOKUj3iebmQOaw-dCE7h8OM9R_qA8o55rKBUa_RxkqvDRoGstEJQaj1XoNmUeQ-uqsZ5SblgmKlMZZ9L_jgYIuNzi-3sMZImszIA-SnsqQvbeofipbSdd2kslgIbmBlkJMc71oRVW4VIEFjAPLSdNVQMNU8MpBFeX6Ny3kNOHMrYhBSz7GxmWiJKs5nK9x-aYXPF03ZrWwCjm146PtCtcX6MsjRRr0LDybWiVh5qe4BCwn4YV8XDo-1MDysVe5hl57f0qw8v3TVllHiFmWzbtl0eWr-8JT2bZq7O4C_gOj6Db90JuiKC8DaJNxoenLmNNkLG6ICxjkhr8Qxohw_jZujVVahap24bFrcpZ0GnW9WrrL3xUxGqzPHM_y6xraCHw6mY-5x3UKnUgCtgmKvsm-ABYxxMcjuTu21AwnTmFRTUeP60QaL5uZqypg6CKtpcay-fGm2JwLzNUFOtDBSj2ARohKVmBmeuCgOoXcbKf214FXaXsIMUqwWtDOPAMbMDX3j5bDkyTA1gNjQ7OTD7JewGHJb8P7cTHEGq2-NciAXssfgt5-blyedZAAL96W2Gwwsn6BV25dpc0gStVUq7qYb7Qgyuj5gxOAooBqt6tuAhe8_WA6QkXwwfjbv8ZdWEcGua9xoZZlhesHCK7-W5sDl0nDoiv3Ntj4w-0pz4rhuXSErfrNurplkmOKUmEIW58MR6oERFiHXE5G0Q6yfalZMSTYrmZl3_jamlmwFNQWFqrarb6DfhiSugpCpNkUZNQfAtP7J1uA59XjW1wCNkNuDoXrN8m9szRNRNAHC-wtbnRRLDNkAKlmiyk2Mst0OLn-n1LQnptGuSoLwPKUM6T2E-mp5a5MymuUK_6ZTjGPNek8GJp_hcDjCLVzkYYqUcNJNPYGgDlsfGkuRg4wrcndTObxLBtHOz5yi5qdan6w2bKpkq6J53garlWvtk8WOOoLQxpVSyjBKzJdx_XK3L_kjJbzWxhvCXFqZD7B3H1ppgRimeu0BZVHAR9-ISnwkS_9QUD7CbNnqxB73WMVOX7_Ai_rt6LYqZ3DBZA8cmianF-vEvkpteg7leeYl1iNxZVn-qPCrMERd9NcZ4msbTOZWEeNJyrcpKJ8eQLcRJnnsjMgisPPa49eqF7UXLMVTt6pfdGx6YHpxc31QNlrx9DV-XObzEkjD-HRaDSnFjI2Jjz3JW8rdKNDbZ41wTFGfU7S00EWAKcfhpOLtsEx6fnO7vUZd69vdltYRF13ikmM-goAB2YZJXx41zLHrZCd6JRN6VYxw3vxcPAafUzbK_hAPX6ZVsOLF-Zp-QfK_q-vA0kFrbtfoU0BzeiX-YA629wcuRl1HrtEXIdfmPS0s_Xs394nLA_ih8YvBW_b9U9hjsANcobMghfJsO17Y77drl3e09mRI905eFSxjPf-bl7Ba0RaP3AD6AN9QBATAv1liguqu88H2giY_Zfecpnyp8HEOlYq9a8xuqiHgSXT_JWxgf3orVtyms2TBaRD-lfnCkz1MmrSfK_RyaEi5gssUuYYHaQlwZmsVHQ3QsHUVvLp8cnnFaCw71Ns9pGv1teIjkveLHj0ODvJsXZ_2D9dN9i2m_5c3g0L7OaGTNOxTW8e8vq1AaXzO1gwpuxCex6tXMt-IaY2Ayh1CBTgfEnYyQjV0wgvPUZcW4QzDiq_EZtXifCZtwEccwIH2hio1XsG8qSWbkqwbYvHCi-rcsUIKHEud71TBBz99uw3-amfPFXgPc6s1TintOyJxii3PtBHWFBg" />
    </form>
    <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7a1565df2f6a27ad')"></div>
    <script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.vultr.com',
            cType: 'non-interactive',
            cNounce: '885',
            cRay: '7a1565df2f6a27ad',
            cHash: 'ed3f0e93d9e5345',
            cUPMDTk: "\/dist\/js\/main.js?v=1677691956&__cf_chl_tk=uKGf1B2XdG7WbLSF8d6f_tuCdVYInTLOuyfQx9TT42s-1677715629-0-gaNycGzNB3s",
            cFPWv: 'g',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 1,
            cTplB: 'cf',
            cRq: {
                ru: 'aHR0cHM6Ly93d3cudnVsdHIuY29tL2Rpc3QvanMvbWFpbi5qcz92PTE2Nzc2OTE5NTY=',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: '+Er39yaQO6mhR+v9V6BCL8u9GLXji+L4iVN3jEZfZEgbHUtphU66i2p7CnAmn5z6xLgptMVhlVv2kiboUCROmfi8Ws8R4aecj7//mQ9h6L1ROI1hVKxo8qBSROGQwCWc5Z6lukXouQqSNKVvjkKaN5sw2FGR1aKG6000qpy7897FQzSsTOEpBCtAyUD9PMfF6GNqg6EQnAo6znivpG9p6dHkfz+u62yxp2SBJxDYC9wnSuf//cxphyvXva9kj+vFq9fovd43H+dMsLZXnOqtqGDgJXYCX6MepnLDZxWjwA35QyQQuIBKvg7XzEpGLmoc8J1m901/qrZI+wbwvNXOW+fg6XNdAGrCrVAW9Bxqx4FTLUT0zbHe/PRk66hyvKGyk6zjoZYmzRd3YkJB3yVRVokeut74hJgT8945R73lWR9+VDlql1bvGC2oLWz9fw+W04KZLmxZIOORH6Ut7uWRnSwzcg9g5yJzk5WSCKhEnPIOUbJUSr86dtcISUhZLGETZQZhLH7fp3NQMltl1IHF2lErzOTfjBaJMEFqdITWOHJv6Z5fYTrLD/BOwXd35tLHXSBdDQcd0tBznldEBaEaTd/MWdJSBnAhQjDoVHV0PD3wyDV/+5nR4Phhhl8IX7m6fsLO79eOOv4AM4MbXJOSAZ5D5YjS9A2ynPfRif2/4OdvuoHgGj2/Zd1IBz0GqkUBL9Mw5KVnEuP7RZb2/ycIzg==',
                t: 'MTY3NzcxNTYyOS45NDUwMDA=',
                m: 'yhHYl2oMiswA/pVrLjCYnuyAv5sh5WbNw9CLn0r15SI=',
                i1: '0G+ntuvMKKnVyKxKOP959Q==',
                i2: 'oFVtbqvabyM41UzrIscQkg==',
                zh: 'iQUouBNODGunr/NCuWfbRWWi0vP5Aj9NLkfKOZFVYyQ=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: '5G1zbnNPGlGRafw4p4kPAVAJ2/sq1g7EvlHwL4GBL7Q=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7a1565df2f6a27ad');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/g/orchestrate/jsch/v1?ray=7a1565df2f6a27ad';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/dist\/js\/main.js?v=1677691956&__cf_chl_rt_tk=uKGf1B2XdG7WbLSF8d6f_tuCdVYInTLOuyfQx9TT42s-1677715629-0-gaNycGzNB3s" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>

</div>

		</div>
		<footer>
			<span id="previous_url"></span>
		</footer>
		<script type="text/javascript">function httpGetAsync(e,t){var n=new XMLHttpRequest;n.onreadystatechange=function(){4==n.readyState&&200==n.status&&t(n.responseText)},n.open("GET",e,!0),n.send(null)}function getIP(e){var t=/ip=(.*)$/m.exec(e);t&&(document.getElementById("your_ip").innerHTML="Your IP: "+t[1]),console.log(t)}httpGetAsync("/cdn-cgi/trace",getIP);</script>
	</body>
</html>